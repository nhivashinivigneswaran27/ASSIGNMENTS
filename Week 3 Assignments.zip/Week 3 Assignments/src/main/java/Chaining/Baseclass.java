package Chaining;

import org.testng.annotations.BeforeMethod;

import io.restassured.RestAssured;
import io.restassured.specification.RequestSpecification;

public class Baseclass {
	
	public static String sys_id;
 public static RequestSpecification inputRequest;
 @BeforeMethod
	public void precondition() {
		RestAssured.baseURI ="https://dev120862.service-now.com/api/now/table/incident";
		inputRequest = RestAssured
				.given()
				.log()
				.all()
				.auth()
				.basic("admin", " FohJdpe7Tc1T^ZJ%");
}
}
