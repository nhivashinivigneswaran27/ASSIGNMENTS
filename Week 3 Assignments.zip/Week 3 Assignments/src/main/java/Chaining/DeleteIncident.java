package Chaining;


import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;


public class DeleteIncident extends Baseclass
{
@Test(dependsOnMethods="Chaining.Updateincident.Patchrequest")
	public void Deleterequest() {
		
	Response response=inputRequest.delete(sys_id);
		response.then().log().all().assertThat().statusCode(204);
}
	
	
}
