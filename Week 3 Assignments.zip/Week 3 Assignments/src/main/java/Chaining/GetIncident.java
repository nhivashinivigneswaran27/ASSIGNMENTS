package Chaining;

import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.Test;

import io.restassured.RestAssured;

import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class GetIncident extends Baseclass 
{

	@Test(dependsOnMethods="Chaining.CreateIncident.PostRequest")
	public void GetRequest() {
		RestAssured.baseURI ="https://dev120862.service-now.com/api/now/table/incident";
		RestAssured.authentication = RestAssured.basic("admin", "FohJdpe7Tc1T^ZJ%");
		
		
		
		Map<String, String> allQueryParam = new HashMap<String, String>();
		allQueryParam.put("sysparm_fields", "sys_id, category, short_description, number");
		
		
											inputRequest.queryParams(allQueryParam);
											
											
		
		Response response = inputRequest.get(sys_id);
		response.then().log().all().assertThat().statusCode(200);
}
}
