package Chaining;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Updateincident extends Baseclass {
	@Test(dependsOnMethods="Chaining.GetIncident.GetRequest")
	public void Patchrequest() {
		RestAssured.baseURI ="https://dev120862.service-now.com/api/now/table/incident";
		RestAssured.authentication = RestAssured.basic("admin", "FohJdpe7Tc1T^ZJ%");
		
		File inputFile = new File("./src/main/resources/Update_incident.json");
		
		Map<String, String> allQueryParam = new HashMap<String, String>();
		allQueryParam.put("sysparm_fields", "sys_id, category, short_description, number");
		
		
		                                     inputRequest
											.queryParams(allQueryParam)
											.contentType(ContentType.JSON)
											.accept(ContentType.JSON)
											.body(inputFile);
		
		Response response = inputRequest.patch(sys_id);
		response.then().log().all().assertThat().statusCode(200);

	
}
}
