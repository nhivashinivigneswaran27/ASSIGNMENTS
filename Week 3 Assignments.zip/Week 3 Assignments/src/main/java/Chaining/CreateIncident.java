package Chaining;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class CreateIncident extends Baseclass {
	@Test
	public void PostRequest() {
	File inputFile = new File("./src/main/resources/Create_Incident.json");
		
		Map<String, String> allQueryParam = new HashMap<String, String>();
		allQueryParam.put("sysparm_fields", "sys_id, category, short_description, number");
		
		
	
	
		inputRequest.queryParams(allQueryParam)
											.contentType(ContentType.JSON)
											.accept(ContentType.JSON)
											.body(inputFile);
		
		Response response = inputRequest.post();
		response.then().log().all().assertThat().statusCode(201);

	
		
		//String sys_id = response.jsonPath().get("result.sys_id");
		//System.out.println("sys_id: "+sys_id);
	}
}
